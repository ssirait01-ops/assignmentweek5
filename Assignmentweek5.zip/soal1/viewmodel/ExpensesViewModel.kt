package com.bruce.week5assignment.soal1.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.bruce.week5assignment.soal1.model.Expense

class ExpensesViewModel : ViewModel() {
    var expenses by mutableStateOf(listOf<Expense>())
        private set
    var expenseName by mutableStateOf("")
        private set
    var expenseAmount by mutableStateOf("")
        private set
    var nameError by mutableStateOf<String?>(null)
        private set
    var amountError by mutableStateOf<String?>(null)
        private set
    var editingId by mutableStateOf<Long?>(null)
        private set

    private var nextId = 1L

    // Total dihitung dari daftar terbaru, termasuk setelah edit dan hapus.
    val totalExpenses: Long
        get() = expenses.sumOf { it.amount }

    fun updateName(name: String) {
        expenseName = name
        nameError = null
    }

    fun updateAmount(amount: String) {
        expenseAmount = amount
        amountError = null
    }

    fun saveExpense(): Boolean {
        val amount = expenseAmount.trim().toLongOrNull()
        nameError = if (expenseName.isBlank()) "Nama pengeluaran tidak boleh kosong" else null
        amountError = when {
            expenseAmount.isBlank() -> "Nominal tidak boleh kosong"
            amount == null -> "Masukkan nominal dalam angka rupiah tanpa titik atau koma"
            amount <= 0 -> "Nominal harus lebih dari 0"
            else -> null
        }
        if (nameError != null || amountError != null || amount == null) return false

        val totalLain = expenses.filter { it.id != editingId }.sumOf { it.amount }
        if (amount > Long.MAX_VALUE - totalLain) {
            amountError = "Total pengeluaran terlalu besar"
            return false
        }

        val id = editingId
        if (id == null) {
            expenses = expenses + Expense(nextId++, expenseName.trim(), amount)
        } else {
            expenses = expenses.map {
                if (it.id == id) it.copy(name = expenseName.trim(), amount = amount) else it
            }
        }
        cancelEdit()
        return true
    }

    fun editExpense(expense: Expense) {
        editingId = expense.id
        expenseName = expense.name
        expenseAmount = expense.amount.toString()
        nameError = null
        amountError = null
    }

    fun deleteExpense(id: Long) {
        expenses = expenses.filter { it.id != id }
        if (editingId == id) cancelEdit()
    }

    fun cancelEdit() {
        editingId = null
        expenseName = ""
        expenseAmount = ""
        nameError = null
        amountError = null
    }
}
