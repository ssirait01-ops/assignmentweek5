package com.bruce.week5assignment.soal1.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bruce.week5assignment.ui.theme.Week5AssignmentTheme
import com.bruce.week5assignment.soal1.viewmodel.ExpensesViewModel
import java.text.NumberFormat
import java.util.Locale

@Composable
fun ExpensesView(
    modifier: Modifier = Modifier,
    expensesViewModel: ExpensesViewModel = viewModel()
) {
    val focusManager = LocalFocusManager.current
    val formatRupiah = remember { NumberFormat.getInstance(Locale.forLanguageTag("id-ID")) }
    val isEditing = expensesViewModel.editingId != null
    val nameError = expensesViewModel.nameError
    val amountError = expensesViewModel.amountError
    val saveExpense = {
        if (expensesViewModel.saveExpense()) focusManager.clearFocus()
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(Color(0xFFFAF8FF)).imePadding(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Expenses", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Total Expenses: Rp ${formatRupiah.format(expensesViewModel.totalExpenses)}",
                    fontSize = 14.sp,
                    color = Color.DarkGray
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = expensesViewModel.expenseName,
                    onValueChange = expensesViewModel::updateName,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Expense Name") },
                    singleLine = true,
                    isError = nameError != null,
                    supportingText = if (nameError != null) {
                        { Text(nameError) }
                    } else null,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = expensesViewModel.expenseAmount,
                        onValueChange = expensesViewModel::updateAmount,
                        modifier = Modifier.weight(1f),
                        label = { Text("Amount of Expense") },
                        prefix = { Text("Rp ") },
                        singleLine = true,
                        isError = amountError != null,
                        supportingText = if (amountError != null) {
                            { Text(amountError) }
                        } else null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { saveExpense() })
                    )
                    IconButton(
                        onClick = saveExpense,
                        modifier = Modifier.padding(top = 8.dp).size(48.dp)
                    ) {
                        Icon(
                            imageVector = if (isEditing) Icons.Default.Check else Icons.Default.Add,
                            contentDescription = if (isEditing) "Simpan perubahan" else "Tambah pengeluaran",
                            tint = Color(0xFF6650A4)
                        )
                    }
                }
                if (isEditing) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Edit pengeluaran", fontSize = 12.sp, color = Color(0xFF6650A4))
                        TextButton(onClick = { expensesViewModel.cancelEdit() }) { Text("Batal") }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
        items(expensesViewModel.expenses, key = { it.id }) { expense ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE0E3F8))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Name: ${expense.name}", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("Rp ${formatRupiah.format(expense.amount)}", fontSize = 13.sp, color = Color.DarkGray)
                    }
                    IconButton(onClick = { expensesViewModel.editExpense(expense) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit ${expense.name}", tint = Color(0xFF9A6700), modifier = Modifier.size(20.dp))
                    }
                    IconButton(onClick = { expensesViewModel.deleteExpense(expense.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Hapus ${expense.name}", tint = Color(0xFFBA1A1A), modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
        if (expensesViewModel.expenses.isEmpty()) {
            item {
                Text(
                    text = "Belum ada pengeluaran. Isi nama dan nominal, lalu tekan +.",
                    fontSize = 14.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun ExpensesPreview() {
    Week5AssignmentTheme(darkTheme = false, dynamicColor = false) {
        ExpensesView(expensesViewModel = remember {
            ExpensesViewModel().apply {
                updateName("Makan siang")
                updateAmount("25000")
                saveExpense()
                updateName("Kopi")
                updateAmount("15000")
                saveExpense()
            }
        })
    }
}
