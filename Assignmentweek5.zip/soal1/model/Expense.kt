package com.bruce.week5assignment.soal1.model

data class Expense(
    val id: Long,
    val name: String,
    val amount: Long
)
