package com.bruce.week5assignment.soal2.model

data class Question(
    val id: Int,
    val text: String,
    val options: List<String>,
    val correctAnswerIndex: Int
)

data class QuizAnswer(
    val question: Question,
    val selectedAnswerIndex: Int
) {
    val isCorrect: Boolean
        get() = selectedAnswerIndex == question.correctAnswerIndex
}
