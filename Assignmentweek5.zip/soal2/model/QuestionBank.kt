package com.bruce.week5assignment.soal2.model

object QuestionBank {
    val questions = listOf(
        Question(
            id = 1,
            text = "Berapa hari dalam satu minggu?",
            options = listOf("5 hari", "6 hari", "7 hari", "8 hari"),
            correctAnswerIndex = 2
        ),
        Question(
            id = 2,
            text = "Apa hasil dari 8 × 7?",
            options = listOf("48", "54", "56", "64"),
            correctAnswerIndex = 2
        ),
        Question(
            id = 3,
            text = "Planet apa yang dikenal sebagai Planet Merah?",
            options = listOf("Venus", "Mars", "Jupiter", "Saturnus"),
            correctAnswerIndex = 1
        ),
        Question(
            id = 4,
            text = "Apa bahasa pemrograman yang digunakan pada project ini?",
            options = listOf("Java", "Python", "Kotlin", "Swift"),
            correctAnswerIndex = 2
        ),
        Question(
            id = 5,
            text = "Apa kepanjangan dari MVVM?",
            options = listOf("Model View ViewModel", "Model View Variable", "Main View ViewModel", "Model Value ViewModel"),
            correctAnswerIndex = 0
        )
    )
}
