package com.bruce.week5assignment.soal2.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bruce.week5assignment.soal2.viewmodel.QuizPage
import com.bruce.week5assignment.soal2.viewmodel.QuizViewModel
import com.bruce.week5assignment.ui.theme.Week5AssignmentTheme

@Composable
fun QuizView(modifier: Modifier = Modifier, quizViewModel: QuizViewModel = viewModel()) {
    val focusManager = LocalFocusManager.current
    val countError = quizViewModel.questionCountError
    val startQuiz = {
        if (quizViewModel.startQuiz()) focusManager.clearFocus()
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(Color(0xFFFAF8FF)).imePadding(),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item(key = quizViewModel.halamanApa) {
            when (quizViewModel.halamanApa) {
                QuizPage.Start -> {
                    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Mini Quiz", fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "How many questions do you want? (1–${quizViewModel.maxQuestions})",
                            fontSize = 14.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = quizViewModel.questionCount,
                            onValueChange = quizViewModel::updateQuestionCount,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Number of questions") },
                            singleLine = true,
                            isError = countError != null,
                            supportingText = if (countError != null) {
                                { Text(countError) }
                            } else null,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { startQuiz() })
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = startQuiz,
                            enabled = quizViewModel.canStartQuiz,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            shape = RoundedCornerShape(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4E5D8F))
                        ) { Text("Start Quiz") }
                    }
                }
                QuizPage.Question -> {
                    val question = quizViewModel.currentQuestion
                    if (question != null) {
                        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Question ${quizViewModel.currentQuestionIndex + 1}", fontSize = 24.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(question.text, fontSize = 14.sp, textAlign = TextAlign.Center)
                            Spacer(modifier = Modifier.height(20.dp))
                            question.options.forEachIndexed { index, option ->
                                val isSelected = quizViewModel.selectedAnswerIndex == index
                                Button(
                                    onClick = { quizViewModel.selectAnswer(index) },
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).semantics { selected = isSelected },
                                    shape = RoundedCornerShape(50.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) Color(0xFF4E5D8F) else Color(0xFFDDE2FA),
                                        contentColor = if (isSelected) Color.White else Color(0xFF252A3C)
                                    )
                                ) { Text(option, textAlign = TextAlign.Center) }
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { quizViewModel.nextQuestion() },
                                enabled = quizViewModel.selectedAnswerIndex != null,
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                                shape = RoundedCornerShape(50.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4E5D8F))
                            ) { Text("Next") }
                        }
                    }
                }
                QuizPage.Result -> {
                    val wrongAnswers = quizViewModel.answers.withIndex().filter { !it.value.isCorrect }

                    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Quiz Finished!", fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Your Score: ${quizViewModel.score} / ${quizViewModel.questions.size}", fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(24.dp))
                        if (wrongAnswers.isEmpty()) {
                            Text("Perfect! No wrong answers.", fontSize = 14.sp, color = Color(0xFF4E5D8F), textAlign = TextAlign.Center)
                        } else {
                            wrongAnswers.forEach { (index, answer) ->
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text("Q${index + 1}: ${answer.question.text}", fontSize = 14.sp)
                                    Text(
                                        text = "Your Answer: ${answer.question.options[answer.selectedAnswerIndex]}",
                                        fontSize = 13.sp,
                                        color = Color(0xFFBA1A1A)
                                    )
                                    Text(
                                        text = "Correct Answer: ${answer.question.options[answer.question.correctAnswerIndex]}",
                                        fontSize = 13.sp,
                                        color = Color(0xFF27633D)
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFDADAE3))
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { quizViewModel.restartQuiz() },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            shape = RoundedCornerShape(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4E5D8F))
                        ) { Text("Restart Quiz") }
                        TextButton(onClick = { quizViewModel.backToStart() }) { Text("Ubah jumlah soal", color = Color(0xFF4E5D8F)) }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun QuizPreview() {
    Week5AssignmentTheme(darkTheme = false, dynamicColor = false) {
        QuizView(quizViewModel = remember { QuizViewModel() })
    }
}
