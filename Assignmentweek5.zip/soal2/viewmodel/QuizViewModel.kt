package com.bruce.week5assignment.soal2.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.bruce.week5assignment.soal2.model.Question
import com.bruce.week5assignment.soal2.model.QuestionBank
import com.bruce.week5assignment.soal2.model.QuizAnswer
import kotlin.random.Random

enum class QuizPage { Start, Question, Result }

class QuizViewModel(private val random: Random = Random.Default) : ViewModel() {
    var halamanApa by mutableStateOf(QuizPage.Start)
        private set
    var questionCount by mutableStateOf("3")
        private set
    var questions by mutableStateOf(listOf<Question>())
        private set
    var currentQuestionIndex by mutableStateOf(0)
        private set
    var selectedAnswerIndex by mutableStateOf<Int?>(null)
        private set
    var answers by mutableStateOf(listOf<QuizAnswer>())
        private set

    val maxQuestions: Int
        get() = QuestionBank.questions.size
    val questionCountError: String?
        get() {
            val count = questionCount.trim().toIntOrNull()
            return when {
                questionCount.isBlank() -> null
                count == null -> "Masukkan jumlah soal berupa angka"
                count < 1 -> "Minimal 1 pertanyaan"
                count > maxQuestions -> "Maksimal $maxQuestions pertanyaan"
                else -> null
            }
        }
    val canStartQuiz: Boolean
        get() = questionCount.trim().toIntOrNull() in 1..maxQuestions
    val currentQuestion: Question?
        get() = questions.getOrNull(currentQuestionIndex)
    val score: Int
        get() = answers.count { it.isCorrect }

    fun updateQuestionCount(count: String) {
        questionCount = count
    }

    fun startQuiz(): Boolean {
        if (!canStartQuiz) return false
        val count = questionCount.trim().toInt()
        // Ambil soal tanpa duplikasi dan acak ulang setiap mulai / restart.
        questions = QuestionBank.questions.shuffled(random).take(count)
        currentQuestionIndex = 0
        selectedAnswerIndex = null
        answers = emptyList()
        halamanApa = QuizPage.Question
        return true
    }

    fun selectAnswer(index: Int) {
        val question = currentQuestion ?: return
        if (halamanApa == QuizPage.Question && index in question.options.indices) {
            selectedAnswerIndex = index
        }
    }

    fun nextQuestion() {
        if (halamanApa != QuizPage.Question) return
        val question = currentQuestion ?: return
        val selected = selectedAnswerIndex ?: return
        answers = answers + QuizAnswer(question, selected)
        selectedAnswerIndex = null
        if (currentQuestionIndex == questions.lastIndex) {
            halamanApa = QuizPage.Result
        } else {
            currentQuestionIndex++
        }
    }

    fun restartQuiz() {
        startQuiz()
    }

    fun backToStart() {
        halamanApa = QuizPage.Start
    }
}
